from machine import Pin, ADC
import dht
import gc
import network
import socket
import time
import ujson

try:
    from wifi_info import WIFI_SSID, WIFI_PASSWORD
except ImportError:
    WIFI_SSID = "Ryan "
    WIFI_PASSWORD = "123456789"


# DHT11
DHT11_PIN = 4

# KY-026 flame sensor
FLAME_PIN = 27
FLAME_DETECTED_LEVEL = 1

# RDB223 human sensor
HUMAN_PIN = 26
HUMAN_DETECTED_LEVEL = 1

# Light sensor
LIGHT_ADC_PIN = 35

# MQ135 air quality sensor
MQ135_ADC_PIN = 34
VOLTAGE_DIVIDER_FACTOR = 1.0
MQ135_CALIBRATION_RAW_LOW = 60
MQ135_CALIBRATION_UG_M3_LOW = 16.0
MQ135_CALIBRATION_RAW_HIGH = 85
MQ135_CALIBRATION_UG_M3_HIGH = 29

ADC_MAX = 4095
ADC_REF_VOLTAGE = 3.3
SENSOR_REFRESH_MS = 1000
HTTP_PORT = 80


dht11_sensor = dht.DHT11(Pin(DHT11_PIN))
flame_sensor = Pin(FLAME_PIN, Pin.IN)
human_sensor = Pin(HUMAN_PIN, Pin.IN)
light_sensor = ADC(Pin(LIGHT_ADC_PIN))
mq135_sensor = ADC(Pin(MQ135_ADC_PIN))


for adc_sensor in (light_sensor, mq135_sensor):
    adc_sensor.atten(ADC.ATTN_11DB)
    try:
        adc_sensor.width(ADC.WIDTH_12BIT)
    except AttributeError:
        pass


last_sample_ms = -SENSOR_REFRESH_MS
latest_data = {}


def read_average(sensor, samples=10, delay_ms=20):
    total = 0
    for _ in range(samples):
        total += sensor.read()
        time.sleep_ms(delay_ms)
    return total // samples


def estimate_ug_m3(raw):
    raw_range = MQ135_CALIBRATION_RAW_HIGH - MQ135_CALIBRATION_RAW_LOW
    ug_m3_range = MQ135_CALIBRATION_UG_M3_HIGH - MQ135_CALIBRATION_UG_M3_LOW
    ug_m3 = (
        MQ135_CALIBRATION_UG_M3_LOW
        + (raw - MQ135_CALIBRATION_RAW_LOW) * ug_m3_range / raw_range
    )
    if ug_m3 < 0:
        ug_m3 = 0
    return round(ug_m3, 1)


def air_status(ug_m3):
    if ug_m3 <= 30.0:
        return "Good"
    if ug_m3 <= 80.0:
        return "Moderate"
    if ug_m3 <= 120.0:
        return "Unhealthy for Sensitive"
    if ug_m3 <= 150.0:
        return "Unhealthy"
    if ug_m3 <= 250.0:
        return "Very Unhealthy"
    return "Hazardous"


def round_voltage(value):
    return round(value, 2)


def sample_sensors(force=False):
    global last_sample_ms, latest_data

    now = time.ticks_ms()
    if (
        latest_data
        and not force
        and time.ticks_diff(now, last_sample_ms) < SENSOR_REFRESH_MS
    ):
        return latest_data

    data = {
        "ok": True,
        "uptime_seconds": time.ticks_ms() // 1000,
        "errors": [],
    }

    try:
        dht11_sensor.measure()
        data["temperature_c"] = dht11_sensor.temperature()
        data["humidity_percent"] = dht11_sensor.humidity()
    except OSError as exc:
        data["ok"] = False
        data["errors"].append("DHT11 read failed: {}".format(exc))
        data["temperature_c"] = None
        data["humidity_percent"] = None

    try:
        flame_raw = flame_sensor.value()
        data["flame_raw"] = flame_raw
        data["flame_detected"] = flame_raw == FLAME_DETECTED_LEVEL
    except Exception as exc:
        data["ok"] = False
        data["errors"].append("KY-026 read failed: {}".format(exc))
        data["flame_raw"] = None
        data["flame_detected"] = None

    try:
        human_raw = human_sensor.value()
        data["human_raw"] = human_raw
        data["human_detected"] = human_raw == HUMAN_DETECTED_LEVEL
    except Exception as exc:
        data["ok"] = False
        data["errors"].append("RDB223 read failed: {}".format(exc))
        data["human_raw"] = None
        data["human_detected"] = None

    try:
        light_raw = read_average(light_sensor)
        light_voltage = light_raw * ADC_REF_VOLTAGE / ADC_MAX
        data["light_raw"] = light_raw
        data["light_voltage"] = round_voltage(light_voltage)
    except Exception as exc:
        data["ok"] = False
        data["errors"].append("Light sensor read failed: {}".format(exc))
        data["light_raw"] = None
        data["light_voltage"] = None

    try:
        mq135_raw = read_average(mq135_sensor, delay_ms=30)
        gpio_voltage = mq135_raw * ADC_REF_VOLTAGE / ADC_MAX
        mq135_voltage = gpio_voltage * VOLTAGE_DIVIDER_FACTOR
        mq135_ug_m3 = estimate_ug_m3(mq135_raw)
        data["mq135_raw"] = mq135_raw
        data["mq135_gpio_voltage"] = round_voltage(gpio_voltage)
        data["mq135_voltage"] = round_voltage(mq135_voltage)
        data["mq135_ug_m3"] = mq135_ug_m3
        data["air_status"] = air_status(mq135_ug_m3)
    except Exception as exc:
        data["ok"] = False
        data["errors"].append("MQ135 read failed: {}".format(exc))
        data["mq135_raw"] = None
        data["mq135_gpio_voltage"] = None
        data["mq135_voltage"] = None
        data["mq135_ug_m3"] = None
        data["air_status"] = None

    last_sample_ms = now
    latest_data = data
    return data


def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)

    if not wlan.isconnected():
        print("Connecting to Wi-Fi:", WIFI_SSID)
        wlan.connect(WIFI_SSID, WIFI_PASSWORD)
        for _ in range(30):
            if wlan.isconnected():
                break
            time.sleep(1)
            print(".", end="")
        print()

    if not wlan.isconnected():
        raise RuntimeError("Could not connect to Wi-Fi")

    ip = wlan.ifconfig()[0]
    print("Wi-Fi connected")
    print("Open this address in your browser: http://{}/".format(ip))
    return ip


def html_page(ip_address):
    return """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ESP32 Sensor Dashboard</title>
  <style>
    :root {{
      color-scheme: light dark;
      font-family: Arial, Helvetica, sans-serif;
      background: #f4f7f8;
      color: #172026;
    }}
    body {{
      margin: 0;
      min-height: 100vh;
      background: linear-gradient(135deg, #eef7f3 0%, #f8fafc 48%, #edf2f7 100%);
    }}
    main {{
      width: min(980px, calc(100% - 28px));
      margin: 0 auto;
      padding: 24px 0 36px;
    }}
    header {{
      display: flex;
      justify-content: space-between;
      gap: 12px;
      align-items: flex-end;
      margin-bottom: 18px;
    }}
    h1 {{
      margin: 0;
      font-size: 28px;
      line-height: 1.1;
    }}
    .ip {{
      font-size: 14px;
      color: #4b5d67;
    }}
    .grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
      gap: 12px;
    }}
    .card {{
      background: rgba(255, 255, 255, 0.92);
      border: 1px solid #d8e3e6;
      border-radius: 8px;
      padding: 14px;
      box-shadow: 0 6px 18px rgba(20, 37, 47, 0.08);
    }}
    .label {{
      font-size: 13px;
      color: #5a6c75;
      margin-bottom: 7px;
    }}
    .value {{
      font-size: 28px;
      font-weight: 700;
      line-height: 1.15;
    }}
    .unit {{
      font-size: 15px;
      color: #5a6c75;
      margin-left: 3px;
    }}
    .meta {{
      margin-top: 8px;
      font-size: 12px;
      color: #667882;
    }}
    .status {{
      display: inline-flex;
      align-items: center;
      min-height: 28px;
      border-radius: 999px;
      padding: 0 10px;
      font-size: 13px;
      font-weight: 700;
      color: #fff;
      background: #667882;
    }}
    .status.good {{ background: #14805e; }}
    .status.warn {{ background: #a86200; }}
    .status.danger {{ background: #ba2f2f; }}
    .charts {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 12px;
      margin-top: 12px;
    }}
    .chart-card {{
      min-width: 0;
    }}
    .chart-title {{
      display: flex;
      justify-content: space-between;
      gap: 10px;
      align-items: baseline;
      color: #23323a;
      font-size: 15px;
      font-weight: 700;
    }}
    .chart-title span {{
      color: #667882;
      font-size: 12px;
      font-weight: 600;
    }}
    canvas {{
      width: 100%;
      height: 210px;
      display: block;
      margin-top: 10px;
    }}
    .footer {{
      display: flex;
      justify-content: space-between;
      gap: 12px;
      margin-top: 14px;
      font-size: 13px;
      color: #596b73;
    }}
    .errors {{
      margin-top: 12px;
      padding: 10px 12px;
      border-radius: 8px;
      border: 1px solid #f0b8b8;
      background: #fff4f4;
      color: #8c1f1f;
      display: none;
      font-size: 13px;
    }}
    @media (max-width: 620px) {{
      header, .footer {{
        display: block;
      }}
      .ip {{
        margin-top: 6px;
      }}
      h1 {{
        font-size: 24px;
      }}
      canvas {{
        height: 180px;
      }}
    }}
  </style>
</head>
<body>
  <main>
    <header>
      <div>
        <h1>ESP32 Sensor Dashboard</h1>
        <div class="ip">http://{ip_address}/</div>
      </div>
      <span id="boardStatus" class="status">Starting</span>
    </header>

    <section class="grid">
      <article class="card">
        <div class="label">Temperature</div>
        <div class="value"><span id="temperature">--</span><span class="unit">C</span></div>
        <div class="meta">DHT11 on GPIO 4</div>
      </article>
      <article class="card">
        <div class="label">Humidity</div>
        <div class="value"><span id="humidity">--</span><span class="unit">%</span></div>
        <div class="meta">DHT11 on GPIO 4</div>
      </article>
      <article class="card">
        <div class="label">Flame</div>
        <div class="value"><span id="flameStatus" class="status">--</span></div>
        <div id="flameRaw" class="meta">Raw: --</div>
      </article>
      <article class="card">
        <div class="label">Human Detection</div>
        <div class="value"><span id="humanStatus" class="status">--</span></div>
        <div id="humanRaw" class="meta">Raw: --</div>
      </article>
      <article class="card">
        <div class="label">Light Sensor</div>
        <div class="value"><span id="lightVoltage">--</span><span class="unit">V</span></div>
        <div id="lightRaw" class="meta">Raw: --</div>
      </article>
      <article class="card">
        <div class="label">MQ135 Air Quality Estimate</div>
        <div class="value"><span id="mq135UgM3">--</span><span class="unit">ug/m3</span></div>
        <div><span id="airStatus" class="status">--</span></div>
        <div id="mq135Raw" class="meta">Raw: --</div>
        <div id="mq135Voltage" class="meta">A0: -- V, GPIO34: -- V</div>
      </article>
    </section>

    <section class="charts">
      <article class="card chart-card">
        <div class="chart-title">Temperature <span>C over 5 min</span></div>
        <canvas id="temperatureChart" width="640" height="220"></canvas>
      </article>
      <article class="card chart-card">
        <div class="chart-title">Humidity <span>% over 5 min</span></div>
        <canvas id="humidityChart" width="640" height="220"></canvas>
      </article>
      <article class="card chart-card">
        <div class="chart-title">Air Quality <span>ug/m3 over 5 min</span></div>
        <canvas id="airQualityChart" width="640" height="220"></canvas>
      </article>
    </section>

    <div id="errors" class="errors"></div>
    <div class="footer">
      <span id="updated">Waiting for data...</span>
      <span id="uptime">Uptime: -- s</span>
    </div>
  </main>

  <script>
    const $ = (id) => document.getElementById(id);
    const HISTORY_MS = 5 * 60 * 1000;
    const charts = [
      {{
        canvas: $("temperatureChart"),
        field: "temperature_c",
        color: "#c44747",
        unit: "C",
        decimals: 1,
        minRange: 10,
        points: []
      }},
      {{
        canvas: $("humidityChart"),
        field: "humidity_percent",
        color: "#2374ab",
        unit: "%",
        decimals: 0,
        minRange: 10,
        points: []
      }},
      {{
        canvas: $("airQualityChart"),
        field: "mq135_ug_m3",
        color: "#14805e",
        unit: "ug/m3",
        decimals: 1,
        minRange: 10,
        points: []
      }}
    ];

    function valueOrDash(value) {{
      return value === null || value === undefined ? "--" : value;
    }}

    function setStatus(element, text, level) {{
      element.textContent = text;
      element.className = "status " + level;
    }}

    function formatTime(timestamp) {{
      const date = new Date(timestamp);
      const hours = String(date.getHours()).padStart(2, "0");
      const minutes = String(date.getMinutes()).padStart(2, "0");
      return hours + ":" + minutes;
    }}

    function resizeCanvas(canvas) {{
      const rect = canvas.getBoundingClientRect();
      const pixelRatio = window.devicePixelRatio || 1;
      const width = Math.max(1, Math.floor(rect.width * pixelRatio));
      const height = Math.max(1, Math.floor(rect.height * pixelRatio));

      if (canvas.width !== width || canvas.height !== height) {{
        canvas.width = width;
        canvas.height = height;
      }}

      return {{
        width: rect.width,
        height: rect.height,
        pixelRatio: pixelRatio
      }};
    }}

    function addChartSamples(data) {{
      const now = Date.now();
      const cutoff = now - HISTORY_MS;

      charts.forEach((chart) => {{
        const value = Number(data[chart.field]);
        if (!Number.isNaN(value)) {{
          chart.points.push({{ time: now, value: value }});
        }}
        chart.points = chart.points.filter((point) => point.time >= cutoff);
      }});

      drawCharts(now);
    }}

    function drawCharts(now) {{
      charts.forEach((chart) => drawChart(chart, now));
    }}

    function drawChart(chart, now) {{
      const canvas = chart.canvas;
      const size = resizeCanvas(canvas);
      const ctx = canvas.getContext("2d");
      const width = size.width;
      const height = size.height;
      const padding = {{ left: 48, right: 14, top: 12, bottom: 34 }};
      const plotWidth = width - padding.left - padding.right;
      const plotHeight = height - padding.top - padding.bottom;
      const startTime = now - HISTORY_MS;

      ctx.setTransform(size.pixelRatio, 0, 0, size.pixelRatio, 0, 0);
      ctx.clearRect(0, 0, width, height);
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, width, height);

      ctx.font = "11px Arial, Helvetica, sans-serif";
      ctx.lineWidth = 1;

      const visiblePoints = chart.points.filter((point) => point.time >= startTime);
      let minValue = 0;
      let maxValue = 1;

      if (visiblePoints.length) {{
        minValue = visiblePoints[0].value;
        maxValue = visiblePoints[0].value;
        visiblePoints.forEach((point) => {{
          if (point.value < minValue) {{
            minValue = point.value;
          }}
          if (point.value > maxValue) {{
            maxValue = point.value;
          }}
        }});

        const dataRange = maxValue - minValue;
        if (dataRange < chart.minRange) {{
          const centerValue = (maxValue + minValue) / 2;
          minValue = centerValue - chart.minRange / 2;
          maxValue = centerValue + chart.minRange / 2;
        }} else {{
          const yPadding = dataRange * 0.15;
          minValue -= yPadding;
          maxValue += yPadding;
        }}

        if (chart.field !== "temperature_c" && minValue < 0) {{
          maxValue += 0 - minValue;
          minValue = 0;
        }}
      }}

      const xForTime = (timestamp) =>
        padding.left + ((timestamp - startTime) / HISTORY_MS) * plotWidth;
      const yForValue = (value) =>
        padding.top + (1 - (value - minValue) / (maxValue - minValue)) * plotHeight;

      ctx.strokeStyle = "#d6e2e6";
      ctx.fillStyle = "#667882";
      ctx.textAlign = "right";
      ctx.textBaseline = "middle";
      for (let i = 0; i <= 4; i++) {{
        const y = padding.top + (plotHeight * i) / 4;
        const value = maxValue - ((maxValue - minValue) * i) / 4;
        ctx.beginPath();
        ctx.moveTo(padding.left, y);
        ctx.lineTo(width - padding.right, y);
        ctx.stroke();
        ctx.fillText(value.toFixed(chart.decimals), padding.left - 8, y);
      }}

      ctx.textAlign = "center";
      ctx.textBaseline = "top";
      for (let i = 0; i <= 5; i++) {{
        const timestamp = startTime + (HISTORY_MS * i) / 5;
        const x = padding.left + (plotWidth * i) / 5;
        ctx.beginPath();
        ctx.moveTo(x, padding.top);
        ctx.lineTo(x, padding.top + plotHeight);
        ctx.stroke();
        ctx.fillText(formatTime(timestamp), x, padding.top + plotHeight + 9);
      }}

      ctx.strokeStyle = "#95a8b0";
      ctx.beginPath();
      ctx.moveTo(padding.left, padding.top);
      ctx.lineTo(padding.left, padding.top + plotHeight);
      ctx.lineTo(width - padding.right, padding.top + plotHeight);
      ctx.stroke();

      if (!visiblePoints.length) {{
        ctx.fillStyle = "#667882";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("Waiting for data...", padding.left + plotWidth / 2, padding.top + plotHeight / 2);
        return;
      }}

      ctx.strokeStyle = chart.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      visiblePoints.forEach((point, index) => {{
        const x = xForTime(point.time);
        const y = yForValue(point.value);
        if (index === 0) {{
          ctx.moveTo(x, y);
        }} else {{
          ctx.lineTo(x, y);
        }}
      }});
      ctx.stroke();

      const latestPoint = visiblePoints[visiblePoints.length - 1];
      const latestX = xForTime(latestPoint.time);
      const latestY = yForValue(latestPoint.value);
      ctx.fillStyle = chart.color;
      ctx.beginPath();
      ctx.arc(latestX, latestY, 3.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#23323a";
      ctx.textAlign = "left";
      ctx.textBaseline = "bottom";
      ctx.fillText(
        latestPoint.value.toFixed(chart.decimals) + " " + chart.unit,
        Math.min(latestX + 8, width - padding.right - 70),
        Math.max(latestY - 6, 14)
      );
    }}

    async function refreshData() {{
      try {{
        const response = await fetch("/data");
        const data = await response.json();

        $("temperature").textContent = valueOrDash(data.temperature_c);
        $("humidity").textContent = valueOrDash(data.humidity_percent);
        $("lightVoltage").textContent = valueOrDash(data.light_voltage);
        $("lightRaw").textContent = "Raw: " + valueOrDash(data.light_raw);
        $("mq135UgM3").textContent = valueOrDash(data.mq135_ug_m3);
        $("mq135Raw").textContent = "Raw: " + valueOrDash(data.mq135_raw);
        $("mq135Voltage").textContent =
          "A0: " + valueOrDash(data.mq135_voltage) +
          " V, GPIO34: " + valueOrDash(data.mq135_gpio_voltage) + " V";
        $("uptime").textContent = "Uptime: " + valueOrDash(data.uptime_seconds) + " s";
        $("updated").textContent = "Last update: " + new Date().toLocaleTimeString();

        setStatus(
          $("flameStatus"),
          data.flame_detected ? "Detected" : "Clear",
          data.flame_detected ? "danger" : "good"
        );
        $("flameRaw").textContent = "Raw: " + valueOrDash(data.flame_raw);

        setStatus(
          $("humanStatus"),
          data.human_detected ? "Detected" : "Clear",
          data.human_detected ? "warn" : "good"
        );
        $("humanRaw").textContent = "Raw: " + valueOrDash(data.human_raw);

        const airLevel = data.air_status === "Good"
          ? "good"
          : data.air_status === "Moderate" ? "warn" : "danger";
        setStatus($("airStatus"), valueOrDash(data.air_status), airLevel);
        setStatus($("boardStatus"), data.ok ? "Online" : "Sensor Warning", data.ok ? "good" : "warn");
        addChartSamples(data);

        if (data.errors && data.errors.length) {{
          $("errors").style.display = "block";
          $("errors").textContent = data.errors.join(" | ");
        }} else {{
          $("errors").style.display = "none";
          $("errors").textContent = "";
        }}
      }} catch (error) {{
        setStatus($("boardStatus"), "Offline", "danger");
        $("errors").style.display = "block";
        $("errors").textContent = "Could not fetch sensor data.";
        drawCharts(Date.now());
      }}
    }}

    refreshData();
    setInterval(refreshData, 1000);
    window.addEventListener("resize", () => drawCharts(Date.now()));
  </script>
</body>
</html>
""".format(ip_address=ip_address)


def http_response(body, content_type="text/html; charset=utf-8", status="200 OK"):
    if isinstance(body, str):
        body = body.encode("utf-8")
    headers = (
        "HTTP/1.1 {}\r\n"
        "Content-Type: {}\r\n"
        "Content-Length: {}\r\n"
        "Connection: close\r\n"
        "\r\n"
    ).format(status, content_type, len(body))
    return headers.encode("utf-8") + body


def start_server(ip_address):
    addr = socket.getaddrinfo("0.0.0.0", HTTP_PORT)[0][-1]
    server = socket.socket()
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(addr)
    server.listen(2)
    print("Web server listening on http://{}:{}/".format(ip_address, HTTP_PORT))

    while True:
        client = None
        try:
            client, client_addr = server.accept()
            request = client.recv(1024).decode("utf-8")
            request_line = request.split("\r\n", 1)[0]
            parts = request_line.split()
            path = parts[1] if len(parts) >= 2 else "/"

            if path.startswith("/data"):
                data = sample_sensors()
                response = http_response(ujson.dumps(data), "application/json")
            elif path == "/" or path.startswith("/?"):
                response = http_response(html_page(ip_address))
            else:
                response = http_response("Not found", "text/plain", "404 Not Found")

            client.sendall(response)
        except Exception as exc:
            print("Request failed:", exc)
            if client:
                try:
                    client.sendall(
                        http_response(
                            "Internal server error",
                            "text/plain",
                            "500 Internal Server Error",
                        )
                    )
                except Exception:
                    pass
        finally:
            if client:
                client.close()
            gc.collect()


ip = connect_wifi()
sample_sensors(force=True)
start_server(ip)
