import numpy as np
import matplotlib.pyplot as plt
import Numerical_Solution as ns  

def get_cl_for_n(n, target_alpha):
    ns.npts = n
    ns.Points = np.zeros((n, 2))
    ns.Control = np.zeros((n-1, 2))
    ns.Normal = np.zeros((n-1, 2))
    ns.Amat = np.zeros((n, n))
    ns.nondim_Gamma = np.zeros(n)
    
    ns.alpha = target_alpha * np.pi / 180.0
    
    ns.setup() 
    ns.solve() 
    return ns.coefficients()

# =====================================网格无关性验证主程序===================================================
target_alpha = 5.0      
n_list = np.arange(20, 510, 10) 
tolerance = 1e-5        

cl_results = []
best_n = None
print("-" * 50)
print(f"{'节点数 (N)':<12} | {'升力系数 (cl)':<15} | {'变化量 (Delta cl)':<15}")
print("-" * 50)

for i, n in enumerate(n_list):
    cl = get_cl_for_n(n, target_alpha)
    cl_results.append(cl)
    
    if i == 0:
        print(f"{n:<12} | {cl:<15.6f} | {'N/A':<15}")
    else:
        delta_cl = abs(cl_results[i] - cl_results[i-1])
        print(f"{n:<12} | {cl:<15.6f} | {delta_cl:<15.6f}")
        
        if delta_cl < tolerance and best_n is None:
            best_n = n

print("-" * 50)
if best_n:
    print(f"\n>>> 结论：根据容差 {tolerance}，推荐的最佳节点数为 n = {best_n}")

plt.figure(figsize=(8, 5))
plt.plot(n_list, cl_results, 'k-o', linewidth=2, markersize=5)
if best_n:
    best_index = np.where(n_list == best_n)[0][0]
    plt.plot(best_n, cl_results[best_index], 'ro', markersize=10, label=f'Optimal N = {best_n}')
    plt.axvline(x=best_n, color='r', linestyle='--', alpha=0.5)
# ==========================================================================================================
plt.xlabel('Number of Nodes ($N$)')
plt.ylabel('Lift Coefficient ($c_l$)')
plt.title('Mesh Convergence Study ($c_l$ vs. Number of Nodes)')
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend()
plt.tight_layout()
plt.show()