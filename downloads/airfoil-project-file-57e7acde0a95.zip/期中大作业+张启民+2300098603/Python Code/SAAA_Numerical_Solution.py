import numpy as np
import matplotlib.pyplot as plt
np.set_printoptions(precision=15)
pi = np.pi
#注意：此代码文件是小攻角近似后的计算
#========================Input 区域========================
#翼型模型
Airfoil_model = 'NACA4412'
#涡面法的节点数量
npts = 250 
#绘制cl-alpha曲线图时攻角（alpha）的范围 ,单位：度
alpha_start = -5.0
alpha_end = 5
alpha_steps = 250
#绘制Cp-x/c曲线图时的攻角，单位：度
target_alpha_deg = 5
#===========================================================

m = float(Airfoil_model[4]) / 100
p = float(Airfoil_model[5]) / 10 
t = float(Airfoil_model[6:]) / 100 
Points = np.zeros((npts,2))
Control = np.zeros((npts-1,2))
Normal = np.zeros((npts-1,2))
Amat = np.zeros((npts,npts))
nondim_Gamma = np.zeros(npts)

def geometry(x):
    camber = np.zeros(2)
    upper = np.zeros(2)
    lower = np.zeros(2)

    if x == 0.0:
        pass 
    else:
        if x < p:
            yc = m*(2.0*(x/p) - (x/p)**2)
            dydx = 2.0*m/p*(1.0 - x/p)
        else:
            yc = m*(2.0*(1.0-x)/(1.0-p) - ((1.0-x)/(1.0-p))**2)
            dydx = -2.0*m/(1.0-p)*(1.0 - (1.0-x)/(1.0-p))

        camber[0] = x
        camber[1] = yc
        thick = t*(2.969*np.sqrt(x) - 1.260*x - 3.516*x**2 + 2.843*x**3 - 1.015*x**4) 
        
        denom = np.sqrt(1.0 + dydx**2)
        upper[0] = x  - thick / (2.0 * denom) * dydx
        upper[1] = yc + thick / (2.0 * denom)
        lower[0] = x  + thick / (2.0 * denom) * dydx
        lower[1] = yc - thick / (2.0 * denom)

    return camber, upper, lower

def meshing():
    np2 = int(npts/2)
    if npts % 2 == 0:
        dtheta = 2.0*pi/float(npts-1)
        for i in range(np2):
            x = 0.5*(1.0-np.cos((float(i+1)-0.5)*dtheta))
            camber, Points[np2+i,:], Points[np2-i-1,:] = geometry(x)
    else:
        dtheta = pi/float(np2)
        for i in range(np2):
            x = 0.5*(1.0-np.cos(float(i+1)*dtheta))
            camber, Points[np2+1+i,:], Points[np2-1-i,:] = geometry(x)

    for i in range(npts-1):
        Control[i,0] = 0.5*(Points[i,0] + Points[i+1,0])
        Control[i,1] = 0.5*(Points[i,1] + Points[i+1,1])
        Normal[i,0] = - (Points[i+1,1] - Points[i,1])
        Normal[i,1] =   (Points[i+1,0] - Points[i,0])
        Normal[i,:] = normalize(Normal[i,:])

def normalize(v):
    mag = np.sqrt(v[0]**2 + v[1]**2)
    return v / mag

def P_mat(point1, point2, poi):
    A = np.zeros((2,2))
    B = np.zeros((2,2))

    li = np.sqrt((point2[0]-point1[0])**2 + (point2[1]-point1[1])**2)
    dx = point2[0]-point1[0]; dy = point2[1]-point1[1]
    
    A[0,0] =  dx; A[0,1] = dy
    A[1,0] = -dy; A[1,1] = dx
    vec1 = poi - point1
    vec2 = 1.0/li * np.matmul(A, vec1)
    xi = vec2[0]; eta = vec2[1]
    
    phi = np.arctan2(eta*li, eta**2 + xi**2 - xi*li)
    psi = 0.5*np.log((xi**2 + eta**2)/((xi-li)**2 + eta**2))
    
    A[0,0] = dx; A[0,1] = -dy
    A[1,0] = dy; A[1,1] =  dx
    
    B[0,0] = (li-xi)*phi + eta*psi;      B[0,1] = xi*phi - eta*psi
    B[1,0] = eta*phi - (li-xi)*psi - li; B[1,1] = -eta*phi - xi*psi + li
    
    P = 1.0/(2.0*pi*li**2) * np.matmul(A,B)
    return P

def nondim_velocity(point):
    V = np.zeros(2)
    for i in range(npts-1):
        P = P_mat(Points[i,:], Points[i+1,:], point)
        V = V + np.matmul(P, nondim_Gamma[i:i+2])
    #小攻角近似
    V[0] = V[0] + 1
    V[1] = V[1] + alpha
    
    Cp = 1.0 - (V[0]**2 + V[1]**2)
    return V, Cp

        
def setup():
    global Amat
    meshing()

    for i in range(npts-1):
        x1, y1 = Points[i,0], Points[i,1]
        x2, y2 = Points[i+1,0], Points[i+1,1]
        li = np.sqrt((x2-x1)**2 + (y2-y1)**2)
        for j in range(npts-1):
            P = P_mat(Points[j,:], Points[j+1,:], Control[i,:])
            Amat[i,j] =   Amat[i,j]   + (x2-x1)/li*P[1,0] - (y2-y1)/li*P[0,0]
            Amat[i,j+1] = Amat[i,j+1] + (x2-x1)/li*P[1,1] - (y2-y1)/li*P[0,1]
    
    Amat[npts-1,0] = 1.0
    Amat[npts-1,npts-1] = 1.0 

def solve():
    global nondim_Gamma
    B = np.zeros(npts)
    for i in range(npts-1):
        x1, y1 = Points[i,0], Points[i,1]
        x2, y2 = Points[i+1,0], Points[i+1,1]
        li = np.sqrt((x2-x1)**2 + (y2-y1)**2)
        #小攻角近似
        B[i] = ((y2-y1) * 1 - (x2-x1) * alpha) / li
    B[npts-1] = 0.0
    nondim_Gamma = np.linalg.solve(Amat, B)

def coefficients():
    cl = 0.0
    for i in range(npts-1):
        x1, y1 = Points[i,0], Points[i,1]
        x2, y2 = Points[i+1,0], Points[i+1,1]
        G1 = nondim_Gamma[i]
        G2 = nondim_Gamma[i+1]
        li = np.sqrt((x2-x1)**2 + (y2-y1)**2)
        cl = cl + li*(G1+G2)
    return cl

def plotting(alphas_deg, cl_list):
    global alpha 
    alphas_rad = alphas_deg * pi / 180.0
    dcl_da = np.gradient(cl_list, alphas_rad) 
    plt.figure(figsize=(18, 5))
    mid_index = len(dcl_da) // 2
    slope_constant = dcl_da[mid_index]

    # 绘制 cl 曲线
    plt.subplot(1, 3, 1)
    plt.plot(alphas_deg, cl_list, 'b-o', linewidth=2, markersize=4)
    plt.xlabel('Angle of Attack (deg)')
    plt.ylabel('Lift Coefficient ($c_l$)')
    plt.title(f'Lift Curve ({Airfoil_model})')
    plt.grid(True, linestyle='--', alpha=0.6)

    # 绘制斜率 dcl/da 曲线
    plt.subplot(1, 3, 2)
    plt.plot(alphas_deg, dcl_da, 'r-^', linewidth=2, markersize=4)
    plt.text(0, slope_constant + 0.05, f'$K_2$ $\\approx$ {slope_constant:.2f}', color='red', fontsize=12, fontweight='bold', ha='center', va='bottom')
    plt.axhline(y=2*pi, color='k', linestyle='--', alpha=0.5, label='Thin Airfoil Theory (2$\pi$)') 
    plt.ylim(5.0, 8.0)
    plt.xlabel('Angle of Attack (deg)')
    plt.ylabel('$dc_l/d\\alpha$ (1/rad)')
    plt.title(f'Lift Curve Slope ({Airfoil_model})')
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.6)

    # 计算并绘制特定攻角下的 Cp 曲线
    print(f"Calculating Surface Pressure for Alpha = {target_alpha_deg}°...")
    alpha = target_alpha_deg * pi / 180.0
    solve()

    Cp = np.zeros(npts-1)
    offset = 0.001
    for i in range(npts-1):
        V, Cp[i] = nondim_velocity(Control[i,:] + offset * Normal[i,:])

    plt.subplot(1, 3, 3)
    plt.plot(Control[:,0], Cp, 'k-', linewidth=2)
    plt.gca().invert_yaxis() 
    plt.xlabel('x/c')
    plt.ylabel('Pressure Coefficient ($C_p$)')
    plt.title(f'Surface Pressure ({Airfoil_model}, $\\alpha$={target_alpha_deg}°)')
    plt.grid(True, linestyle='--', alpha=0.6)

    plt.tight_layout()
    plt.show()

if __name__ == '__main__':
    setup()
    alphas_deg = np.linspace(alpha_start, alpha_end, alpha_steps) 
    cl_list = []
    for a in alphas_deg:
        alpha = a * pi / 180.0  
        solve()                 
        cl = coefficients()     
        cl_list.append(cl)
    plotting(alphas_deg, cl_list)